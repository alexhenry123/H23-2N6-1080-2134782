# Boucle for standard. Utilisez le débogueur pour voir les valeurs
# prise par les différentes variables lors de l'exécution.
liste_cours = ["Prog 1", "Math", "Bureautique"]

for cours in liste_cours :
    print("Bienvenue au cours : ")
    print(cours)