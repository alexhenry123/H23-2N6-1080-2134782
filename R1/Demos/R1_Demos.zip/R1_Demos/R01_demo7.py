nom = input("Écriver votre nom : ")
print(f"Bonjour {nom}.")

# Écriver un second input qui demmande votre age.
# ajouter une condition qui regarde si age > 65 
# et qui imprime un message indiquant si vous vous qualifier pour des rabais de l'age d'or

