# Typage dynamique
# Assigner des valeurs aux variables afin qu'elles soient du type désiré, la changer si nécessaire.

variable = 32
print(f"""\nLa variable est : {type(variable)}""")

variable = 3      # changer la variable en type float
print(f"""La variable est : {type(variable)}""")

variable = 2    # changer la variable en type  boolean
print(f"""La variable est : {type(variable)}""")

variable = 2     # changer la variable en type  string
print(f"""La variable est : {type(variable)}\n""")
