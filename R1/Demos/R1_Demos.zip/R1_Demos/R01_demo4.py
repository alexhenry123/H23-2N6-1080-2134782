# strings et f-strings
prenom = "vincent"
nom = "brousseau"
Local_de_travail = "ED1"
num_ordinateur = "PORT29"

#obtener le poste de travail en faisant une concatenation du local_de_travail et du num_ordinateur
poste_de_travail = ""

#Imprimer le msg suivant :
#   Bonjour Vincent Brousseau
#   Votre poste est le ED1PORT29
print(f""" """)