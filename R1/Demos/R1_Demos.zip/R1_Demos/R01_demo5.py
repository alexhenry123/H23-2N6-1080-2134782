# exemple if, elif, else
x = float(input("\nInserez la valeur de x : "))

if x < 0 :
    print("La valeur de x est négative")
elif x > 0 :
    print("La valeur de x est positif")
else:
    print("La valeur est 0")
print("")