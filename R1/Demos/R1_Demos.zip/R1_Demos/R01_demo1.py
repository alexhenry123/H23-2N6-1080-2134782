nombre_un = 10
nombre_deux = 15

print("demo if/else/elif et tabulation")

if nombre_un < nombre_deux :    #print le plus petit nombre

elif nombre_deux == nombre_un:  # print un message "egal"

else :                          #print le plus grand nombre
