cours = ['Programmation 1', 'Math', 'Bureautique', 'Réseau 1','Math']
print(cours)
#ajouter le cours "Math" à la fin avec append()
print("\n\n1-append" + 50*"_")
cours
print(cours)

#Afficher le nombre de fois que le cours "Math" apparait
print("\n\n2-count" + 50*"_")
nb = None
print(nb)

#ajouter les cours "AI", "Systèmes" à la liste avec extend()
print("\n\n3-extend" + 50*"_")
courses_opt = None
cours
print(cours)

#trouver l'index du cours "Bureautique" en utilisant index()
print("\n\n4-index" + 50*"_")
index = None
print(index)

#ajouter un cours "BD2" après "Bureautique" en utilisant insert() avec l'index que nous venons de découvrir.
print("\n\n5-insert" + 50*"_")
print(cours)

#Enlever le cours "AI" de la liste avec remove()
print("\n\n6-remove" + 50*"_")
cours
print(cours)

#Enlever le dernier item de la liste avec pop(). L'item enlevé est retourné par pop#
print("\n\n7-pop" + 50*"_")
cours_removed = None
print(cours_removed)
print(cours)

#Metter la lise de cours en ordre croissant avec sort()
#Puis metter la liste en ordre décroissant
print("\n\n8-sort" + 50*"_")
cours
print(cours)
cours
print(cours)