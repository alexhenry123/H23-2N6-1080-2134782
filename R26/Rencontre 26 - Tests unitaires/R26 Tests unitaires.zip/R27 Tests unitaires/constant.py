MAX_TEMPERATURE = 35
MIN_TEMPERATURE = 5
TEMPERATURE_INITIALE = 20

NB_MAX_ETUDIANTS = 3     # nb maximal d'étudiants par groupe

#En réalité la notion de constantes n'existe pas en Python
#C'est une convention de les mettre dans un fichier appelé constant.py
#Et de les écrire en majuscules

#Pour penser à ne pas leur donner de nouvelles valeurs
#Mais en fait, il est toujours possible de leur donner de nouvelles valeurs.