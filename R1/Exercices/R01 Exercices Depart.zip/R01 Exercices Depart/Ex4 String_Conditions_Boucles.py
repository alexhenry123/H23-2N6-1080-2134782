# RAPPEL
# groupe = "1020"    
# print(dir(groupe))  #montre toutes les méthodes disponibles pour la variable groupe#
# #help#
# print(help(str)) #montre ce que fait chacune des méthodes de la classe str#
# print(help(str.find)) #montre ce que fait la méthode find de la classe str# 


exercice_sep = "___________________________________"
# Pour chaque question ci-dessous, faites le code demandé puis imprimez toujours exercice_sep ensuite afin de séparer les questions


nom_fichier = "Liste étudiants gr1010"
#  Vous savez que le groupe est toujours les 4 derniers caractères du nom de fichier#
# Q1 Faites le code nécessaire pour obtenir ces 4 derniers caractères en utilisant le slicing à partir de la fin #




# Q2 Imprimez chacun des caractères du nom_fichier en utilisant for, len et range #





    
# Q3 Imprimez chacun des caractères du nom_fichier de façon INVERSÉE en utilisant for, len et range et un indice #
# que vous modifierez dans la boucle for#








# Q4 Vérifiez si le mot un_mot est un palindrome  
# Vous pouvez commencer par inverser un_mot dans un_autre_mot
# Puis comparez les deux mots
# Faites ensuite la structure if...else... pour afficher les messages suivants:
#    Si la condition est vraie, affichez un message comme quoi le mot est un palindrome
#    Si la contition est fausse, affichez un message comme quoi le mot trouvé n'est pas un palindrom

# Ainsi, avec le mot "kayak" le résultat attendu est "Le mot kayak est un palindrome"






# Q5 Changez la question précédente pour obtenir un mot de l'usager 
# Faire en sorte que ce code fonctionne en boucle tant que le mot entré n'est pas 'stop' #



