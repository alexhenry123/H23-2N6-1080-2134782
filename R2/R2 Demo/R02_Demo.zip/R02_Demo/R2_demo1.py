#utilisation de l'index pour les listes
cours = ['Programmation 1', 'Math', 'Bureautique', 'Réseau 1','Math',"Programmation 2", "Programmation 3", "Pogrammation Web"]

#imprimer le premire cours

#imprimer les 6 premiers cours

#imprimer le dernier cours

#imprimer les 3 derniers cours

#imprimer la liste troquer d'une valeur
