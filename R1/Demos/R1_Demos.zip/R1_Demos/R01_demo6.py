# demo de boucles


liste_os_supporter = ["Win 10", "WinXp", "WinVista", "macOS", 
                      "iOS", "Android", "Chrome Os","Win7", 
                      "Ubuntu 22.02", "Linux Mint","Win 8.1"]

__, ___ = None, [None] # deux variables vides qui devront être remplacer.

print("\nListe des os avec boucle while : ")
i = 0
while ( ):      # completer la boucle while pour imprimer chaque os dans la lise
    pass    # retirer "pass", il s'agit d'une instruction permettant d'éviter les messages d'erreurs.

print("\nListe des os avec boucle for : ")
for  __  in ___ : # completer la boucle for pour imprimer chaque os dans la lise
    pass

print("\nListe des os windows avec boucle for : ")
for  __  in ___ : # ajouter une condition pour que seul les os commencant par "Win sont imprimer"
    pass
