#Vous avez une classe Cercle qui a un attribut privé rayon (_rayon)

class Cercle:
    def __int__(self, rayon):
        self._rayon = rayon

