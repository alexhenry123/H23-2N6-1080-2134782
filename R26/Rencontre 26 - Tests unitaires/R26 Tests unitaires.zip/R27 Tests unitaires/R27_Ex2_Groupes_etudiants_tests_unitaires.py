import R27_Ex2_Groupes_etudiants as Ge
import unittest
from constant import *

class Test_ajouter_etudiant(unittest.TestCase):

    def test_ajouter_1_etudiant_depasse_max(self):
       # Instanciez 3 étudiants
       # Instanciez un groupe avec une liste de 3 etudiants
       # Instanciez un autre étudiant
       # Vérifiez que vous obtenez une erreur quand vous testez l'ajout de cet autre étudiant
       self.fail("À faire")

    def test_ajouter_1_etudiant_ok(self):
        # Instanciez un etudiant
        # Instanciez un groupe avec cet etudiant
        # Instanciez un autre étudiant
        # Testez l'ajout de cet autre étudiant
        # Vérifiez que le dernier étudiant du groupe est celui que vous avez ajouté
        # Vérifiez que le nombre d'étudiants du groupe est maintenant de 2
       self.fail("À faire")




if __name__ == '__main__':
    unittest.main(verbosity=2)