import customtkinter as ctk
import R27_Ex3_Choix_pc as Cpc
import unittest
from constant import *


class Test_estimer(unittest.TestCase):

    def test_estimer_sans_processeur(self):
        # Instanciez la classe Choix

        # Testez que le choix du processeur est   "Choisis ton processeur    "

        #           faites l'appel de la méthode estimer()

        # Vérifier que le texte du lbl_message est égal à "Tu dois choisir un processeur"

        self.fail("À faire")

    def test_estimer_sans_carte_graphique(self):
        # Cette fois-ci donnez un choix valide pour le processeur
        self.fail("À faire")

    def test_estimer_sans_RAM(self):
        # Cette fois-ci donnez un choix valide pour le processeur et pour la carte graphique
        self.fail("À faire")

    def test_estimer_les_3_choix(self):
        # Instanciez la classe Choix

        # donner le choix de processeur "AMD Ryzen 9 5950X         "

        # donner le choix de carte graphique "GeForce RTX 3090Ti        "

        # donner le choix de barrette RAM  "G.SKILL Trident Z5        "

        #        appeler la méthode estimer()
        
        # Vérifier que le texte du lbl_message est égal à "Pour tes choix, l'estimé est de 3720.26$."
       
        self.fail("À faire")
        
if __name__ == '__main__':
    unittest.main()