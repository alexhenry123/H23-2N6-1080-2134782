class Contact:
    pass


print()
contact_complet = Contact("Anastazie","Nisha","165 rue Pieux", "nisha.A@gmail","5142-111-7272")
contact_valide = Contact("Miklos","Warner",email="nisha.A@gmail")
#contact_invalide = Contact("Erkan","Severie","165 rue Pieux") doit causer une erreur lorsque cette ligne est exécuté.
print()