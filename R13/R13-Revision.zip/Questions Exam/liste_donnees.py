# Vous avez une liste de données et vous voulez :
#           - Mettre la liste en ordre croissant
#           - Retirez le premier et le dernier élément de la liste.
#           - Imprimez la valeur du dernier élément retiré
#           - Imprimez la liste

liste_donnees = [63, 61, 58, 59, 95, 61, 65, 71, 73, 57, 91, 81, 55, 96, 56, 64, 88, 0, 63, 98, 93, 82, 100, 95, 60, 98, 88, 99, 77, 50, 94, 82, 49, 56, 50, 85, 88, 97, 60, 94, 65, 51, 57, 52, 54, 84, 71, 62, 76, 87, 100, 81, 95, 80, 56, 65, 93, 98, 52, 61, 69, 54, 45, 120, 53, 78, 84, 48, 49, 98, 89, 71, 86, 50, 70, 80, 75, 73, 98, 92, 77, 75, 98, 88, 49, 89, 89, 81, 92, 73, 81, 89, 83, 100, 89, 74, 56, 96, 90, 100, 63, 47]



